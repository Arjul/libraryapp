// const express = require('express');
// const deleteRouter = express.Router();
// const BookData = require('../model/bookData');
// function router(nav){
//     deleteRouter.get('/',function(req,res){
//         // BookData.remove() 
//         // .then(function(){
//         //     res.redirect('/books');
//         // })
//     // })   
// }
