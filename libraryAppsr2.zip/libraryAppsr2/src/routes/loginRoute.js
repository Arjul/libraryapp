const express = require('express');
const loginRouter = express.Router();
const signupdata = require('../model/signupData');


function loginRouting(nav){
    loginRouter.get('/',function(req,res){
        res.render("login",{
            nav,
            title:'Library',
            
        });
    });
    loginRouter.post('/submit',function(req,res){
        
        var email = req.body.email;
        var password = req.body.password;
        var check = signupdata.findOne({email:email});
        check.exec(function(err,data){
        if(err) throw err;
        res.redirect('/books');
        
        
        
        });
        
    });
    return loginRouter;
}
module.exports = loginRouting;