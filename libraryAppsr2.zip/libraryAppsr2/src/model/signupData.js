//Accesing mongoose package
const mongoose = require('mongoose');
//DB connection code
mongoose.connect('mongodb://localhost:27017/library');
//Schema definition
const Schema = mongoose.Schema;
const signupSchema =new Schema({
    username : String,
    email : String,
    password : String,
    confirmPassword : String,
    phoneNumber : Number
});
//Model creation
var signupdata = mongoose.model('signupdata',signupSchema);
module.exports = signupdata;